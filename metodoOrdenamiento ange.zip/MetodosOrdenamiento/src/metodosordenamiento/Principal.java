/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodosordenamiento;

import java.util.Scanner;

/**
 *
 * @author Eq4
 */
public class Principal {

    public static int[] llenar() {
        int n;
        System.out.println("inserta el tamaño del arreglo");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();

        int[] numeros = new int[n];
        System.out.println(" arreglo original ");
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = (int) (Math.random() * n) + 1;
        }
        for (int a = 0; a < numeros.length; a++) {
            System.out.print("," + numeros[a]);
        }

    }

    public static int[] burbuja(int numeros[], int n) {
        int aux;
        for (int j = 0; j < numeros.length; j++) {
            if (numeros[j] > numeros[j + 1]) {
                aux = numeros[j + 1];
                numeros[j + 1] = numeros[j];
                numeros[j] = aux;
                j++;
            } else {
                j++;
            }

        }
        System.out.println("este es ell arreglo ordenado burbuja ");
        for (int y = 0; y < numeros.length; y++) {
            System.out.print("," + numeros[y]);
        }
        return numeros;

    }

    public static int[] InserccionDirecta(int numeros[], int n) {
        int aux, j;
        for (int p = 0; p < numeros.length; p++) {
            aux = numeros[p];
            j = p - 1;
            while ((j >= 0) && (aux < numeros[j])) {
                numeros[j + 1] = numeros[j];
                j++;
            }
            numeros[j + 1] = aux;
        }
        System.out.println("este es ell arreglo ordenado por Insercion");
        for (int y = 0; y < numeros.length; y++) {
            System.out.print("," + numeros[y]);
        }
        return numeros;
    }

    public static int[] seleccion(int numeros[], int n) {
        int aux, j = 0;
        int men = 0;
        for (int k = 0; k < numeros.length; k++) {
            for (int h = k + 1; h < numeros.length; h++) {
                if (numeros[j] < numeros[men]) {
                    men = j;
                }
                aux = numeros[k];
                numeros[k] = numeros[men];
                numeros[men] = aux;
                men = k + 1;

            }

        }
        System.out.println("este es ell arreglo ordenado por Seleccion");
        for (int y = 0; y < numeros.length; y++) {
            System.out.print("," + numeros[y]);
        }
        return numeros;
    }

    public static int[] shell(int numeros[], int n) {
        int salto, cambio, j, aux;
        salto = numeros.length / 2;
        while (salto > 2) {
            cambio = 1;
            while (cambio != 0) {
                cambio = 0;
                for (int m = salto; m < numeros.length; m++) {
                    j = m - salto;
                    if (numeros[j] > numeros[m]) {
                        aux = numeros[j];
                        numeros[m] = numeros[m];
                        cambio++;
                    }
                }
                salto /= 2;
            }
            System.out.println("este es ell arreglo ordenado por Shell");
            for (int y = 0; y < numeros.length; y++) {
                System.out.print("," + numeros[y]);
            }
        }
        return numeros;
    }

}

public static void main(String[] args) {   
       
        int[] cadena = new int[100];
    llenar();
          System.out.println(" 1 metodo burbuja");
         System.out.println("2 si : metodo insercionDirecta ");
          System.out.println("3 si :seleccion");
           System.out.println("4 : metodo shell");
        Scanner n = new Scanner(System.in);
        int select = n.nextInt();
       

    burbuja(cadena);
        } if (select==1){
            
        
    insercionDirecta(cadena);
        } if(select==2){
            
        
    seleccion(cadena);
        } else if(select==3){
    shell(cadena);
        }
        
         shell(cadena);
        } else if(select==4){
    shell(cadena);
        }
        
        
    }}
